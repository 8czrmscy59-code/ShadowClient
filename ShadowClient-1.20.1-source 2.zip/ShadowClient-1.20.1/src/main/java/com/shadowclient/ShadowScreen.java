package com.shadowclient;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public class ShadowScreen extends Screen {
    private static final int CYAN = 0xFF35D9FF;
    private static final int PANEL = 0xEE0B1422;
    private static final int MUTED = 0xFF91A7BA;

    private enum Tab {
        HUD("HUD"), VISUALS("VISUALS"), INTERFACE("INTERFACE"), ABOUT("ABOUT");
        final String label;
        Tab(String label) { this.label = label; }
    }

    private Tab activeTab = Tab.HUD;
    private final List<ButtonWidget> tabButtons = new ArrayList<>();
    private final List<ButtonWidget> contentButtons = new ArrayList<>();

    protected ShadowScreen() {
        super(Text.literal("SHADOW CLIENT"));
    }

    @Override
    protected void init() {
        rebuildWidgets();
    }

    private void rebuildWidgets() {
        clearChildren();
        tabButtons.clear();
        contentButtons.clear();

        int panelWidth = Math.min(390, this.width - 32);
        int left = (this.width - panelWidth) / 2;
        int top = Math.max(24, (this.height - 270) / 2);

        int tabY = top + 66;
        int tabWidth = (panelWidth - 28) / 4;
        for (int i = 0; i < Tab.values().length; i++) {
            final Tab tab = Tab.values()[i];
            int x = left + 14 + i * tabWidth;
            ButtonWidget b = ButtonWidget.builder(
                    Text.literal(tab.label),
                    button -> {
                        activeTab = tab;
                        rebuildWidgets();
                    }).dimensions(x, tabY, tabWidth - 4, 22).build();
            tabButtons.add(b);
            addDrawableChild(b);
        }

        int contentY = tabY + 42;
        switch (activeTab) {
            case HUD -> {
                addToggle(left, contentY, panelWidth, "HUD overlay", () -> ShadowClient.hudEnabled,
                        value -> ShadowClient.hudEnabled = value);
                addToggle(left, contentY + 34, panelWidth, "Coordinates", () -> ShadowClient.coordinatesEnabled,
                        value -> ShadowClient.coordinatesEnabled = value);
                addInfo(left, contentY + 82, "Displays your position and client performance.");
            }
            case VISUALS -> {
                addInfo(left, contentY + 4, "Visual settings");
                addInfo(left, contentY + 28, "More client-side visual options can be added here.");
                addInfo(left, contentY + 52, "No changes are made to the game world.");
            }
            case INTERFACE -> {
                addInfo(left, contentY + 4, "Menu theme");
                addInfo(left, contentY + 27, "NEON  •  Dark panels  •  Cyan highlights");
                addInfo(left, contentY + 55, "Open menu: RIGHT SHIFT");
            }
            case ABOUT -> {
                addInfo(left, contentY + 4, "SHADOW CLIENT");
                addInfo(left, contentY + 28, "Minecraft 1.20.1  |  Fabric");
                addInfo(left, contentY + 52, "A lightweight client-side utility mod.");
            }
        }

        ButtonWidget close = ButtonWidget.builder(Text.literal("CLOSE MENU"), button -> close())
                .dimensions(left + 14, top + 222, panelWidth - 28, 22).build();
        addDrawableChild(close);
    }

    private void addToggle(int left, int y, int panelWidth, String label,
                           java.util.function.BooleanSupplier getter,
                           java.util.function.Consumer<Boolean> setter) {
        ButtonWidget b = ButtonWidget.builder(toggleText(label, getter.getAsBoolean()), button -> {
            boolean next = !getter.getAsBoolean();
            setter.accept(next);
            button.setMessage(toggleText(label, next));
        }).dimensions(left + 14, y, panelWidth - 28, 24).build();
        contentButtons.add(b);
        addDrawableChild(b);
    }

    private void addInfo(int left, int y, String message) {
        // Text is rendered by render(); no interactive widget is needed.
    }

    private static Text toggleText(String label, boolean enabled) {
        return Text.literal(label + "     " + (enabled ? "● ON" : "○ OFF"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context);

        int panelWidth = Math.min(390, this.width - 32);
        int left = (this.width - panelWidth) / 2;
        int top = Math.max(24, (this.height - 270) / 2);
        int panelHeight = 260;

        context.fill(left, top, left + panelWidth, top + panelHeight, PANEL);
        context.fill(left, top, left + panelWidth, top + 2, CYAN);
        context.fill(left + 12, top + 48, left + panelWidth - 12, top + 49, 0xFF20364A);

        context.drawTextWithShadow(this.textRenderer, "SHADOW", left + 16, top + 14, 0xFFFFFFFF);
        context.drawTextWithShadow(this.textRenderer, "CLIENT", left + 91, top + 14, CYAN);
        context.drawTextWithShadow(this.textRenderer, "NEON EDITION  •  FABRIC 1.20.1",
                left + 16, top + 31, MUTED);

        int contentY = top + 66 + 22 + 42;
        switch (activeTab) {
            case HUD -> context.drawTextWithShadow(this.textRenderer,
                    "Toggle the on-screen information panel.", left + 14, contentY + 82, MUTED);
            case VISUALS -> {
                context.drawTextWithShadow(this.textRenderer, "VISUAL SETTINGS", left + 14, contentY + 4, CYAN);
                context.drawTextWithShadow(this.textRenderer, "More client-side visual options can be added here.",
                        left + 14, contentY + 28, MUTED);
                context.drawTextWithShadow(this.textRenderer, "No changes are made to the game world.",
                        left + 14, contentY + 52, MUTED);
            }
            case INTERFACE -> {
                context.drawTextWithShadow(this.textRenderer, "MENU THEME", left + 14, contentY + 4, CYAN);
                context.drawTextWithShadow(this.textRenderer, "NEON  •  Dark panels  •  Cyan highlights",
                        left + 14, contentY + 27, MUTED);
                context.drawTextWithShadow(this.textRenderer, "Open menu: RIGHT SHIFT",
                        left + 14, contentY + 55, MUTED);
            }
            case ABOUT -> {
                context.drawTextWithShadow(this.textRenderer, "SHADOW CLIENT", left + 14, contentY + 4, CYAN);
                context.drawTextWithShadow(this.textRenderer, "Minecraft 1.20.1  |  Fabric",
                        left + 14, contentY + 28, MUTED);
                context.drawTextWithShadow(this.textRenderer, "A lightweight client-side utility mod.",
                        left + 14, contentY + 52, MUTED);
            }
        }

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
