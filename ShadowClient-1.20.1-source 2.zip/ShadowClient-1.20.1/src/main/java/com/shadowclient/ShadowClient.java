package com.shadowclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class ShadowClient implements ClientModInitializer {
    public static boolean hudEnabled = true;
    public static boolean coordinatesEnabled = true;

    private static KeyBinding openMenuKey;

    @Override
    public void onInitializeClient() {
        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.shadowclient.open_menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.shadowclient"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.wasPressed()) {
                client.setScreen(new ShadowScreen());
            }
        });

        HudRenderCallback.EVENT.register((drawContext, tickDelta) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (!hudEnabled || client.player == null) return;

            int x = 8;
            int y = 8;
            int cyan = 0xFF35D9FF;

            drawContext.drawTextWithShadow(client.textRenderer,
                    Text.literal("SHADOW CLIENT").styled(s -> s.withColor(cyan)), x, y, cyan);
            y += 12;

            if (coordinatesEnabled) {
                String coords = String.format("XYZ: %.1f / %.1f / %.1f",
                        client.player.getX(), client.player.getY(), client.player.getZ());
                drawContext.drawTextWithShadow(client.textRenderer, coords, x, y, 0xFFFFFFFF);
                y += 12;
            }

            drawContext.drawTextWithShadow(client.textRenderer,
                    "FPS: " + client.getCurrentFps(), x, y, 0xFFB8C7D9);
        });
    }
}
